
<div class='topbar'>
<br> 
<div align='center'> <a class='footerT'>  <span style='color:red;'><</span>
    ORGANIZATORS
    <span style='color:red;'>></span>  </a> </div> 
<br><br>
 <a href='https://www.lata.org.lv/'> <img class='lata' src='https://static.wixstatic.com/media/eece5a_36e0accae0844b83ad5d013908971039~mv2.png/v1/fill/w_510,h_110,al_c,q_85,usm_0.66_1.00_0.01/LATA%20hakatons.webp'>
</div> 


</body>

</html>