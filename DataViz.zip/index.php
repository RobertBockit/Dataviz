
  <?php include 'header.php';?> 
  <?php //include 'table.php'; ?>
  <?php include 'slider.php'; ?>
  <br> <br> <br> 
<a class='footerT' style='margin-left: 31.5%;'><span style='color:red;'><</span>
    Tas, kas mūs iedvesmoja
    <span style='color:red;'>></span>  </a> 
    <br> 
    <div class='paragraph'> 
    <p>Šodien Latvijā, neskatoties uz COVID-19 pandemiju, ir diezgan labi apstākļi jauna biznesa veidošanai vairākas nozarēs. Vairāki uzņēmumi pārtrauca savu darbību, atklājot jaunas iespējas citiem konkurētspējīgiem uzņemējiem. Mūsu portāls atklāj, apstrādā un vizualizē inovatīvā veidā aktuālus ekonomiskus un demogrāfiskus datus, kuri ir nepieciešami, reālistiskai biznesa plānošanai. Šobrid mūsu mājaslapā ir pieejami ģeotelpiskie dati, kas dod jauniem bizness uzņēmumu vadītajiem iespēju balstities plānošana uz lokāliem datiem.</p> </div> 
    <div align='center'><a class='button' href='/data.php'> Apskatīt datus </a> </div> <br> 
    <br> <br>

 <?php  include 'footer.php'; ?>