<?php include 'header.php'?> 
<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
      AUTORS
    <span style='color:red;'>></span>  
  </a> 
</div> 
<br> 
<div align='center' > 
<a class='paragraph' style='font-size: 70px;'> Roberts Terehovičs </a>
</div> 
<br> 
<br> 
<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
      ORGANIZATORI
    <span style='color:red;'>></span>  
  </a> 
</div> 


<br> 

<div>
 <a href='https://www.lata.org.lv/'> <img class='lata' src='https://static.wixstatic.com/media/eece5a_36e0accae0844b83ad5d013908971039~mv2.png/v1/fill/w_510,h_110,al_c,q_85,usm_0.66_1.00_0.01/LATA%20hakatons.webp'>

  <a href='https://www.lata.org.lv/'> <img class='lata' src=' /unnamed.png'>


</div>
<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
      ORGANIZATORA PARTNERI
    <span style='color:red;'>></span>  
  </a> 
</div> 
<br>
<br>
<div align='center'>
  <a href='https://www.lata.org.lv/'> <img style='width: 40%;' src=' https://static.wixstatic.com/media/eece5a_2430f2ee087445bd8152755a65847b3d~mv2.png/v1/fill/w_1330,h_1000,al_c,q_90,usm_0.66_1.00_0.01/HAKATONS%20partneri%202021.webp'>
</div>
<br>
<br>
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
      IZVEIDOTS AR
    <span style='color:red;'>></span>  
  </a> 
</div> 
<div align='center'>
  <a href='https://www.lata.org.lv/'> <img style='width: 40%;' src=' https://www.tableau.com/sites/default/files/pages/tableaulogo_highres.png'>
</div>



