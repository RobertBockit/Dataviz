<html>
  <head >
 
  <link rel="stylesheet" type="text/css" href="style.css">
<title> DataViz </title>
<meta name="viewport" content="width=device-width, initial-scale=1">

  </head>
  <div class='topbar'>
  
   

    <div class='navbar'> 
    <a href='/' class='logo'>
    <span style='color:red;'><</span>
    DataViz
    <span style='color:red;'>></span> 
    </a> 

  <a class='l' href='/'>Sakums</a> 
  <a class='l' href='/data.php'>Dati</a> 
  <a class='l' href='/quiz.php'>Viktorīna</a> 

  <a class='l' href='/Organizatori.php'>Organizatori</a> 
    </div> 

  </div> 


  <body>

