<?php include 'header.php'?>

<!-- All data representation table --> 

<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
     KOPĒJA TABULA
    <span style='color:red;'>></span>  
  </a> 
</div> 
<div align='center' class='table'>
  <?php include 'tables/Overalltable.php'?>
</div>

<!-- Sex and people quantity table --> 

<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
     DZIMUMS UN IEDZĪVOTĀJU SKAITS
    <span style='color:red;'>></span>  
  </a> 
</div> 
<div align='center' class='table'>
  <?php include 'tables/Gendertable.php'?>
</div>

<!-- Age and ethnicity table  --> 

<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
     VECUMS UN TAUTĪBA
    <span style='color:red;'>></span>  
  </a> 
</div> 
<div align='center' class='table'>
  <?php include 'tables/Agetable.php'?>
</div>

<!-- Average and median income   --> 

<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
     VIDĒJIE IEDZĪVOTĀJU IENĀKUMI
    <span style='color:red;'>></span>  
  </a> 
</div> 
<div align='center' class='table'>
  <?php include 'tables/Incometable.php'?>
</div>

<!-- High education and economic values   --> 

<br> 
<div align='center'> 
  <a class='footerT'>
    <span style='color:red;'><</span>
     AUGSTĀKA IZGLĪTĪBA UN EKONOMISKE RADITĀJI
    <span style='color:red;'>></span>  
  </a> 
</div> 
<div align='center' class='table'>
  <?php include 'tables/Edutable.php'?>
</div>

<?php include 'footer.php'?>